using System;
using System.Windows;

namespace WitcherGuiApp
{
    public partial class App : Application
    {
    }
}